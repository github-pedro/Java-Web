package br.com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.ArrayList;
import java.util.Random;

import br.com.BO.jogoBO;
import br.com.model.megasenaModel;
import br.com.model.quinaModel;

/**
 * Servlet implementation class LoteriaController
 */
@WebServlet("/LoteriaController")
public class LoteriaController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoteriaController() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Random random = new Random();
		jogoBO jogo = new jogoBO();
		int quinaNumber = Integer.parseInt(request.getParameter("quinaNumber"));
		int i;
		String acao = request.getParameter("acao");
		if (acao == null) {
			for (i = 0; i < quinaNumber; i++) {
				jogo.addQuina(new quinaModel(random.nextInt(60), random.nextInt(60), random.nextInt(60),
						random.nextInt(60), random.nextInt(60)));
			}
			ArrayList<quinaModel> quinaLista = new ArrayList<quinaModel>();
			quinaLista = jogo.mostrarJogoQuina();
			request.setAttribute("JogoQuina", quinaLista);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Random random = new Random();
		jogoBO jogo = new jogoBO();
		int megasenaNumber = Integer.parseInt(request.getParameter("megasenaNumber"));
		int i;

		String acao = request.getParameter("acao");
		
		
		if (acao != null && acao.equals("mega")) {
			for (i = 0; i < megasenaNumber; i++) {
				jogo.addMega(new megasenaModel(random.nextInt(60), random.nextInt(60), random.nextInt(60),
						random.nextInt(60), random.nextInt(60), random.nextInt(60)));
			}
			ArrayList<megasenaModel> mega = new ArrayList<megasenaModel>();
			mega = jogo.mostrarJogoMega();
			request.setAttribute("JogoMega", mega);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}

	}
}
