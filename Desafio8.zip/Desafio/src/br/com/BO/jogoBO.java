package br.com.BO;

import java.util.ArrayList;

import br.com.DAO.jogoDAO;
import br.com.model.megasenaModel;
import br.com.model.quinaModel;

public class jogoBO {
	
	jogoDAO jogo = new jogoDAO();
	
	public boolean addQuina(quinaModel quina) {
		return jogo.addQuina(quina);
	}
	public boolean addMega(megasenaModel mega) {
		return jogo.addMega(mega);
	}
	public ArrayList<megasenaModel> mostrarJogoMega(){
		return jogo.mostrarJogoMega();
	}
	public ArrayList<quinaModel> mostrarJogoQuina(){
		return jogo.mostrarJogoQuina();
	}
}
