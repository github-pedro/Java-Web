package br.com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import br.com.Connection.ConnectionFactory;
import br.com.model.megasenaModel;
import br.com.model.quinaModel;


public class jogoDAO {
	private Connection connection;
	private PreparedStatement ps;
	private Statement st;
	private ResultSet rs;
	private ArrayList<megasenaModel> mega = new ArrayList<megasenaModel>();
	private ArrayList<quinaModel> quina = new ArrayList<quinaModel>();

	
	public jogoDAO(){
		connection = new ConnectionFactory().getConnection();
	}
	
	public boolean addQuina(quinaModel quina) {
		String sql = "INSERT INTO quina(n1,n2,n3,n4,n5)values(?,?,?,?,?)";
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1,quina.getN1());
			ps.setInt(2,quina.getN2());
			ps.setInt(3,quina.getN3());
			ps.setInt(4,quina.getN4());
			ps.setInt(5,quina.getN5());
			ps.execute();
			ps.close();
			return true;
		}catch(Exception error) {
			return false;
		}
	}
	public boolean addMega(megasenaModel mega) {
		String sql = "INSERT INTO megasena(n1,n2,n3,n4,n5,n6)values(?,?,?,?,?,?)";
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1,mega.getN1());
			ps.setInt(2,mega.getN2());
			ps.setInt(3,mega.getN3());
			ps.setInt(4,mega.getN4());
			ps.setInt(5,mega.getN5());
			ps.setInt(6,mega.getN6());
			ps.execute();
			ps.close();
			return true;
		}catch(Exception error) {
			return false;
		}
	}
	public ArrayList<megasenaModel> mostrarJogoMega(){
		String sql = "Select * from megasena";
		try {
			st = connection.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()){
				mega.add(new megasenaModel(rs.getInt("n1"), rs.getInt("n2"),rs.getInt("n3"),rs.getInt("n4"),rs.getInt("n5"),rs.getInt("n6")));
			}
		}catch(Exception error) {
			System.out.println("Erro "+error);
		}
		return mega;
	}
	public ArrayList<quinaModel> mostrarJogoQuina(){
		String sql = "Select * from quina";
		try {
			st = connection.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()){
				quina.add(new quinaModel(rs.getInt("n1"), rs.getInt("n2"),rs.getInt("n3"),rs.getInt("n4"),rs.getInt("n5")));
			}
		}catch(Exception error) {
			System.out.println("Erro "+error);
		}
		return quina;
	}
	
}
